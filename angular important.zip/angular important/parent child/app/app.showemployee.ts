import { Component,Input,EventEmitter,Output } from '@angular/core';

@Component({
    selector: 'show-comp',
    templateUrl: 'app.showemployee.html'
})

export class ShowEmployeeComponent {
    @Input()  // From parent to child
    inchild:string;
    @Output()  // from child to parent
    notify:EventEmitter<string>=new EventEmitter<string>();

    callingParent1():any
    {
         this.notify.emit("From child to parent data send");
    }

 }