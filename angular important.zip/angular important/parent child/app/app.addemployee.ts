import { Component,Input,EventEmitter,Output } from '@angular/core';

@Component({
    selector: 'add-comp',
    templateUrl: 'app.addemployee.html'
})

export class AddEmployeeComponent {
   @Input()  // From parent to child
    inchild:string;
    @Output()  // from child to parent
    notify:EventEmitter<string>=new EventEmitter<string>();

    callingParent():any
    {
         this.notify.emit("From child to parent data send");
    }
    empName:string="show...";
    message1:string;
    getDataFromChild1(msg1)
    {
      this. message1=msg1;
    }
    

 }