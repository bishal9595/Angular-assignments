import { Component } from "@angular/core";

@Component({

    selector:'add-emp',
   // template:'<h1>In Add Employee Component.....</h1>'
  templateUrl:'app.add.html'
  /*template:`Employee Id is {{empId}} <br/>
   Employee Name is {{empName}} <br/>
   Employee salary is {{empSalary}} <br/>
   
   {{addEmployee()}} `*/
})
export class AddEmployeeComponent
{
  empId:number;
  empId2:number;
  empName:string;
  empSalary:number;
  empId1:number;
  empName1:string;
  empDept1:string;
  empDept:string;
  empSalary1:number;
   emp:any[]=[{empId:1001,empName:"Rahul",empSalary:9000,empDept:"Java"},
            {empId:1002,empName:"Sachin",empSalary:19000,empDept:"OraApps"},
            {empId:1003,empName:"Vikash",empSalary:29000,empDept:"JBI"}];
   
  addEmployee():any{
    var emp:any[]=[];
      this.emp.push({empId:this.empId,empName:this.empName,empSalary:this.empSalary,empDept:this.empDept});
      console.log("employee added"+this.emp);
      alert(+this.empId+" "+this.empName+" "+this.empSalary+" "+this.empDept);
     
  }
  

}