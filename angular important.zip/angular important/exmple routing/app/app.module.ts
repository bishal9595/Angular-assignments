﻿import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }  from './app.component';
import { AddEmployeeComponenent } from './app.addemployee';
import {Routes,RouterModule} from '@angular/router'
import { HttpClientModule } from '@angular/common/http';
import { ShowEmployeeComponenent } from './app.showemployee';
import { SearchEmployeeComponenent } from './app.searchemployee';


const routes:Routes=[{path:'add',component:AddEmployeeComponenent},
        {path:'show',component:ShowEmployeeComponenent},
        {path:'search',component:SearchEmployeeComponenent}];


@NgModule({
    imports: [
        BrowserModule,HttpClientModule,RouterModule.forRoot(routes)

        
    ],
    declarations: [
        AppComponent,AddEmployeeComponenent,ShowEmployeeComponenent,SearchEmployeeComponenent
		],
    providers: [ ],
    bootstrap: [AppComponent]
})

export class AppModule { }