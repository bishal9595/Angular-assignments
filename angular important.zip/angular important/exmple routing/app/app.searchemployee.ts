import { Component} from "@angular/core";

@Component({selector:'search-comp',
templateUrl:'app.searchemployee.html'})

export class SearchEmployeeComponenent 
{
 


  
}