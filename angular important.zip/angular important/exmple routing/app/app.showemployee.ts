import { Component,OnInit} from "@angular/core";
import {EmployeeService} from './app.employeeservice';

@Component({selector:'show-comp',
templateUrl:'app.showemployee.html'})

export class ShowEmployeeComponenent implements OnInit
{
 
  constructor(private myservice:EmployeeService)
  {

  }

  empAll:any[]=[];
  
  ngOnInit()
  {
      this.myservice.getAllEmployee().subscribe((data:any)=>this.empAll=data);
  }
  
}