import { Component} from "@angular/core";

@Component({selector:'add-comp',
templateUrl:'app.addemployee.html'})

export class AddEmployeeComponenent 
{
 


  
}