import { Component } from '@angular/core';

@Component({
    selector: 'wel',
    templateUrl: 'app.welcome.html'
})

export class Welcome { }