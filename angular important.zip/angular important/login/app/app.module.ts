﻿import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {AppComponent} from './app.component'
import {Login} from './app.login';
import {Welcome} from './app.welcome';
import {Register} from './app.register';
import{Routes,RouterModule} from '@angular/router'
import {FormsModule }  from '@angular/forms';
import {HttpClientModule }  from '@angular/common/http';
const routes:Routes=[{path:'',redirectTo:'log',pathMatch:'full'},
        {path:'wel',component:Welcome},
        {path:'log',component:Login},
        {path:'reg',component:Register}
         

];
@NgModule({
    imports: [
        BrowserModule,FormsModule,RouterModule.forRoot(routes),HttpClientModule
        
    ],
    declarations: [
        AppComponent,Login,Welcome,Register],
    providers: [ ],
    bootstrap: [AppComponent]
})

export class AppModule { }