import { Component } from '@angular/core';
import{Router} from '@angular/router'
@Component({
    selector: 'log',
    templateUrl: 'app.login.html'
})

export class Login { 
constructor(private router:Router)
{

}
lid:number;
lpass:string;
ipass:string="vbnm";
aid:number=1234;
check()
{
    if(this.lid==this.aid && this.lpass==this.ipass )
    {
        this.router.navigate(['wel'])
    }
    else{
        alert("Invalid")
    }
}


}