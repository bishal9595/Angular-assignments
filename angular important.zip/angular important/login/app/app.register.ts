import { Component } from '@angular/core';

@Component({
    selector: 'reg',
    templateUrl: 'app.register.html'
})

export class Register { }