import { Component,OnInit } from "@angular/core";
import {BookService} from './app.bookeservice';
@Component({selector:'show-book',
templateUrl:'app.showbooklist.html'})

export class ShowBookComponenent implements OnInit
{
  constructor(private service:BookService)
  {

  } 


  bookAll:any[]=[];
  ngOnInit()
  {
      this.service.getAllBooksDetails().subscribe((data:any)=>this.bookAll=data);

  }

  deleteBook(data:number):any
  {
    this.bookAll.splice(data,1);
  }
  
}