﻿import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }  from './app.component';
import { AddEmployeeComponenent } from './app.addemployee';
import { HttpClientModule } from '@angular/common/http';
import { ShowEmployeeComponenent } from './app.showemployee';
import{FormsModule} from  '@angular/forms'
@NgModule({
    imports: [
        BrowserModule,FormsModule,HttpClientModule

        
    ],
    declarations: [
        AppComponent,AddEmployeeComponenent,ShowEmployeeComponenent
		],
    providers: [ ],
    bootstrap: [AppComponent]
})

export class AppModule { }