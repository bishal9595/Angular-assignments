import { Component,OnInit,Input, SimpleChanges } from "@angular/core";
import {EmployeeService} from './app.employeeservice';
@Component({selector:'show-emp',
templateUrl:'app.showemployee.html'})

export class ShowEmployeeComponenent implements OnInit
{
    @Input()
    empId :number=null;
    @Input()
    empName :string=null;
    @Input()
    empSalary :number=null;
    @Input()
    empDepartment :string=null;
    @Input()
    status:boolean;
    constructor(private service:EmployeeService)
  {

  } 
 ngOnChanges(changes:SimpleChanges){
     if(changes['status']){
         if(this.empId!=null){
             this.empAll.push({empId:this.empId,empName:this.empName,empSalary:this.empSalary,empDepartment:this.empDepartment})
         }
     }
 }

  empAll:any[]=[];
  ngOnInit()
  {
      this.service.getAllEmployee().subscribe((data:any)=>this.empAll=data);

  }
  deleteEmployee(data:number):any{
    this.empAll.splice(data,1);
  }
}
