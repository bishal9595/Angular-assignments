import { Component,OnInit } from "@angular/core";

@Component({selector:'add-comp',
templateUrl:'app.addemployee.html'})

export class AddEmployeeComponenent 
{
  empId:number;
  empName:string;
  empSalary:number;
  empDepartment:string;
  status:boolean;
  addEmployee()
  {
    this.status=!this.status;
  }
  }
