import { Input,Component } from '@angular/core';


@Component({
    selector: 'add-emp',
    templateUrl: 'app.add.html'
})

export class AddEmployeeComponent { 
 empId:number;
  empName:string;
  empSalary:number;
  empDept:string;
  emp:any[]=[
         {empId:101,empName:"abc",empSalary:10000,empDept:"JAVA"},
         {empId:102,empName:"abd",empSalary:20000,empDept:".NET"},
         {empId:103,empName:"abf",empSalary:13000,empDept:"ORACLE"}
  ];
  status:boolean=false;
  addEmployee():any
  {
      this.status=true;
      this.emp.push({empId:this.empId,empName:this.empName,empSalary:this.empSalary,empDept:this.empDept})
  }
 
  

}