let empId:number=1001;
let empName:string="Abcd";
let empSalary:number=10002.33;
let empStatus:boolean=true;



console.log(`Employee name is ${empName} Employee id is ${empId}`);
console.log(`Employee salary is ${empSalary}`);
