"use strict";
exports.__esModule = true;
var IEmployee = /** @class */ (function () {
    function IEmployee() {
    }
    return IEmployee;
}());
exports.IEmployee = IEmployee;
