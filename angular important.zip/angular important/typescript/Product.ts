export class Product
{
    proId:number;
    proName:string;
    proCost:number;
    
}