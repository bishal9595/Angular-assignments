var empId = 1001;
var empName = "Abcd";
var empSalary = 10002.33;
var empStatus = true;
console.log("Employee name is " + empName + " Employee id is " + empId);
console.log("Employee salary is " + empSalary);
